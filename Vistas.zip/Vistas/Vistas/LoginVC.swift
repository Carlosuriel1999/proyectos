//
//  LoginVC.swift
//  Vistas
//
//  Created by Macbook on 11/29/18.
//  Copyright © 2018 Macbook. All rights reserved.
//

import UIKit

class LoginVC: UIViewController {

    @IBOutlet weak var nombre: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func logoutUser(_ sender: UIButton) {
        navigationController?.popViewController(animated: true)
    }
    
}
